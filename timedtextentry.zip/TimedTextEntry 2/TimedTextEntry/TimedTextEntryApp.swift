//
//  TimedTextEntryApp.swift
//  TimedTextEntry
//
//  Created by admin on 11/7/24.
//

import SwiftUI

@main
struct TimedTextEntryApp: App {
    var body: some Scene {
        WindowGroup {
            TabView {
                // First tab
                ContentViewA()
                    .tabItem {
                        Image(systemName: "keyboard")
                        Text("Text Entry")
                    }
                
                // Second tab
                ContentViewB()
                    .tabItem {
                        Image(systemName: "mic")
                        Text("Voice Entry")
                    }
                
                // Add more tabs as needed
                
                ContentViewC()
                    .tabItem {
                        Image(systemName: "keyboard")
                        Text("Typing Composition")
                    }
                
                ContentViewD()
                    .tabItem {
                        Image(systemName: "mic")
                        Text("Voice Composition")
                    }
                
                
            }
        }
    }
}
