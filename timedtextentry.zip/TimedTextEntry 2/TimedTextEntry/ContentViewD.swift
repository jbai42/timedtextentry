import SwiftUI
import Speech
import AVFoundation

struct ContentViewD: View {
    var body: some View {
        FreeSpeechTest()
    }
}

struct FreeSpeechTest: View {
    @StateObject private var speechRecognizer = SpeechRecognizer()
    @State private var spokenText = ""
    @State private var startTime: Date?
    @State private var isTestActive = false
    @State private var results: SpeechTestResults?
    @State private var allResults: [SpeechTestResults] = []
    @State private var showingResults = false
    @State private var showingExporter = false
    @State private var isRecording = false
    @State private var testCount = 0
    
    struct SpeechTestResults: Codable {
        let testIndex: Int
        let spokenText: String
        let wpm: Double
        let timeElapsed: TimeInterval
        let timestamp: Date
        
        enum CodingKeys: String, CodingKey {
            case testIndex = "Test Number"
            case spokenText = "Spoken Text"
            case wpm = "WPM"
            case timeElapsed = "Time Elapsed (seconds)"
            case timestamp = "Timestamp"
        }
    }
    
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Text("Voice Speed Monitor")
                    .font(.largeTitle)
                
                Spacer()
                
                if !allResults.isEmpty {
                    Button(action: {
                        showingExporter = true
                    }) {
                        Label("Export Data", systemImage: "square.and.arrow.up")
                            .padding(8)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
            }
            .padding()
            
            VStack(alignment: .leading) {
                HStack {
                    Text("Test \(testCount + 1)")
                        .font(.headline)
                    Spacer()
                    if !allResults.isEmpty {
                        Text("Average WPM: \(String(format: "%.1f", averageWPM))")
                            .font(.headline)
                    }
                }
            }
            
            if !showingResults {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Recognized Speech:")
                        .font(.headline)
                    Text(spokenText)
                        .padding()
                        .frame(maxWidth: .infinity, minHeight: 50)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                    
                    HStack {
                        Button(action: {
                            if isRecording {
                                stopRecording()
                            } else {
                                startRecording()
                            }
                        }) {
                            HStack {
                                Image(systemName: isRecording ? "stop.circle.fill" : "mic.circle.fill")
                                Text(isRecording ? "Stop Recording" : "Start Recording")
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(isRecording ? Color.red : Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                        }
                        
                        if !spokenText.isEmpty {
                            Button(action: {
                                submitTest()
                                showingResults = true
                            }) {
                                Text("Submit Test")
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                                    .background(Color.green)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                            }
                        }
                    }
                }
            }
            
            if showingResults {
                VStack(spacing: 15) {
                    Text("Test \(testCount) Results")
                        .font(.headline)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("WPM: \(String(format: "%.1f", results?.wpm ?? 0))")
                        Text("Time: \(String(format: "%.1f", results?.timeElapsed ?? 0)) seconds")
                        
                        Divider()
                        
                        Text("You said: \(spokenText)")
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(10)
                    
                    HStack(spacing: 20) {
                        Button(action: {
                            resetTest()
                            showingResults = false
                        }) {
                            Text("Try Again")
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.gray)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                        
                        Button(action: {
                            nextTest()
                            showingResults = false
                        }) {
                            Text("New Test")
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                    }
                }
            }
            
            if !allResults.isEmpty {
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Previous Results:")
                            .font(.headline)
                        ForEach(allResults.indices, id: \.self) { index in
                            HStack {
                                Text("Test \(allResults[index].testIndex + 1):")
                                Text("\(String(format: "%.1f", allResults[index].wpm)) WPM")
                            }
                            .font(.subheadline)
                        }
                    }
                    .padding()
                }
                .frame(maxHeight: 100)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
            }
        }
        .padding()
        .fileExporter(
            isPresented: $showingExporter,
            document: FreeSpeechCSVDocument(results: allResults),
            contentType: .commaSeparatedText,
            defaultFilename: "free_speech_test_results"
        ) { result in
            switch result {
            case .success(let url):
                print("Saved to \(url)")
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    private var averageWPM: Double {
        guard !allResults.isEmpty else { return 0 }
        return allResults.reduce(0.0) { $0 + $1.wpm } / Double(allResults.count)
    }
    
    private func startRecording() {
        startTime = Date()
        isRecording = true
        spokenText = ""
        speechRecognizer.startRecording { text in
            spokenText = text
        }
    }
    
    private func stopRecording() {
        isRecording = false
        speechRecognizer.stopRecording()
    }
    
    private func submitTest() {
        guard let startTime = startTime else { return }
        let timeElapsed = Date().timeIntervalSince(startTime)
        
        // Calculate WPM based on spoken words
        let wordCount = spokenText.split(separator: " ").count
        let minutes = timeElapsed / 60
        let wpm = Double(wordCount) / minutes
        
        let newResults = SpeechTestResults(
            testIndex: testCount,
            spokenText: spokenText,
            wpm: wpm,
            timeElapsed: timeElapsed,
            timestamp: Date()
        )
        
        results = newResults
        allResults.append(newResults)
        testCount += 1
    }
    
    private func nextTest() {
        if isRecording {
            speechRecognizer.stopRecording()
            isRecording = false
        }
        
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        } catch {
            print("Failed to deactivate audio session: \(error)")
        }
        
        spokenText = ""
        startTime = nil
        results = nil
    }
    
    private func resetTest() {
        if isRecording {
            speechRecognizer.stopRecording()
            isRecording = false
        }
        
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        } catch {
            print("Failed to deactivate audio session: \(error)")
        }
        
        spokenText = ""
        startTime = nil
        results = nil
    }
}

// Document type for CSV export
struct FreeSpeechCSVDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.commaSeparatedText] }
    
    var results: [FreeSpeechTest.SpeechTestResults]
    
    init(results: [FreeSpeechTest.SpeechTestResults]) {
        self.results = results
    }
    
    init(configuration: ReadConfiguration) throws {
        results = []
    }
    
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        let headers = ["Test Number", "Spoken Text", "WPM", "Time Elapsed (seconds)", "Timestamp"]
        
        var csvString = headers.joined(separator: ",") + "\n"
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .medium
        
        for result in results {
            let row = [
                String(result.testIndex + 1),
                "\"\(result.spokenText.replacingOccurrences(of: "\"", with: "\"\""))\"",
                String(format: "%.1f", result.wpm),
                String(format: "%.1f", result.timeElapsed),
                "\"\(dateFormatter.string(from: result.timestamp))\""
            ]
            csvString += row.joined(separator: ",") + "\n"
        }
        
        return FileWrapper(regularFileWithContents: Data(csvString.utf8))
    }
}
