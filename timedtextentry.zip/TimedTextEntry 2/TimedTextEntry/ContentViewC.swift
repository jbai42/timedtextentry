import SwiftUI
import UniformTypeIdentifiers

struct TypingMonitor: View {
    @State private var userInput = ""
    @State private var startTime: Date?
    @State private var isActive = true
    @State private var results: SpeedResults?
    @State private var allResults: [SpeedResults] = []
    @State private var showingResults = false
    @State private var showingExporter = false
    @FocusState private var isInputFocused: Bool
    
    struct SpeedResults: Codable {
        let wpm: Double
        let timeElapsed: TimeInterval
        let timestamp: Date
        let typedText: String
        
        enum CodingKeys: String, CodingKey {
            case wpm = "WPM"
            case timeElapsed = "Time Elapsed (seconds)"
            case timestamp = "Timestamp"
            case typedText = "Typed Text"
        }
    }
    
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Text("Typing Speed Monitor")
                    .font(.largeTitle)
                
                Spacer()
                
                if !allResults.isEmpty {
                    Button(action: {
                        showingExporter = true
                    }) {
                        Label("Export Data", systemImage: "square.and.arrow.up")
                            .padding(8)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
            }
            .padding()
            
            if !showingResults {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Start typing to measure your speed:")
                        .font(.headline)
                    TextField("Type here...", text: $userInput)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .focused($isInputFocused)
                        .onAppear { startTest() }
                    
                    Button(action: {
                        submitTest()
                        showingResults = true
                    }) {
                        Text("Calculate Speed")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(userInput.isEmpty ? Color.gray : Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    .disabled(userInput.isEmpty)
                }
            }
            
            if showingResults {
                VStack(spacing: 15) {
                    Text("Results")
                        .font(.headline)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("WPM: \(String(format: "%.1f", results?.wpm ?? 0))")
                        Text("Time Elapsed: \(String(format: "%.1f", results?.timeElapsed ?? 0)) seconds")
                        
                        Divider()
                        
                        Text("You typed:")
                            .foregroundColor(.gray)
                        Text(userInput)
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(10)
                    
                    Button(action: {
                        resetTest()
                        showingResults = false
                    }) {
                        Text("Try Again")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
            }
            
            if !allResults.isEmpty {
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Previous Results:")
                            .font(.headline)
                        ForEach(allResults.indices, id: \.self) { index in
                            HStack {
                                Text("Test \(index + 1):")
                                Text("\(String(format: "%.1f", allResults[index].wpm)) WPM")
                            }
                            .font(.subheadline)
                        }
                    }
                    .padding()
                }
                .frame(maxHeight: 100)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
            }
        }
        .padding()
        .fileExporter(
            isPresented: $showingExporter,
            document: SpeedCSVDocument(results: allResults),
            contentType: .commaSeparatedText,
            defaultFilename: "typing_speed_results"
        ) { result in
            switch result {
            case .success(let url):
                print("Saved to \(url)")
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    private var averageWPM: Double {
        guard !allResults.isEmpty else { return 0 }
        return allResults.reduce(0.0) { $0 + $1.wpm } / Double(allResults.count)
    }
    
    private func startTest() {
        startTime = Date()
        isInputFocused = true
    }
    
    private func submitTest() {
        guard let startTime = startTime else { return }
        let timeElapsed = Date().timeIntervalSince(startTime)
        
        let characterCount = userInput.count
        let minutes = timeElapsed / 60
        let wpm = Double(characterCount) / 5.0 / minutes
        
        let newResults = SpeedResults(
            wpm: wpm,
            timeElapsed: timeElapsed,
            timestamp: Date(),
            typedText: userInput
        )
        
        results = newResults
        allResults.append(newResults)
        isActive = false
    }
    
    private func resetTest() {
        userInput = ""
        startTime = nil
        isActive = true
        results = nil
        isInputFocused = true
        startTest()
    }
}

struct SpeedCSVDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.commaSeparatedText] }
    
    var results: [TypingMonitor.SpeedResults]
    
    init(results: [TypingMonitor.SpeedResults]) {
        self.results = results
    }
    
    init(configuration: ReadConfiguration) throws {
        results = []
    }
    
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        let headers = ["WPM", "Time Elapsed (seconds)", "Timestamp", "Typed Text"]
        
        var csvString = headers.joined(separator: ",") + "\n"
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .medium
        
        for result in results {
            let row = [
                String(format: "%.1f", result.wpm),
                String(format: "%.1f", result.timeElapsed),
                "\"\(dateFormatter.string(from: result.timestamp))\"",
                "\"\(result.typedText)\""
            ]
            csvString += row.joined(separator: ",") + "\n"
        }
        
        return FileWrapper(regularFileWithContents: Data(csvString.utf8))
    }
}

struct ContentViewC: View {
    var body: some View {
        TypingMonitor()
    }
}
