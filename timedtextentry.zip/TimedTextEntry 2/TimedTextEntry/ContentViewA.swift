import SwiftUI
import UniformTypeIdentifiers

struct TypingSpeedTest: View {
    let testPhrases = [
        "My watch fell in the water",
        "Prevailing wind from the east",
        "Never too rich and never too thin",
        "Breathing is difficult",
        "I can see the rings on Saturn",
        "Physics and chemistry are hard",
        "My bank account is overdrawn",
        "Elections bring out the best",
        "We are having spaghetti",
        "Time to go shopping"
    ]
    
    @State private var currentTestIndex = 0
    @State private var userInput = ""
    @State private var startTime: Date?
    @State private var isTestActive = true
    @State private var results: TestResults?
    @State private var allResults: [TestResults] = []
    @State private var showingResults = false
    @State private var showingExporter = false
    @FocusState private var isInputFocused: Bool
    
    struct TestResults: Codable {
        let testIndex: Int
        let phrase: String
        let wpm: Double
        let errorRate: Double
        let timeElapsed: TimeInterval
        let timestamp: Date
        
        // Add coding keys to ensure consistent CSV column ordering
        enum CodingKeys: String, CodingKey {
            case testIndex = "Test Number"
            case phrase = "Test Phrase"
            case wpm = "WPM"
            case errorRate = "Error Rate"
            case timeElapsed = "Time Elapsed (seconds)"
            case timestamp = "Timestamp"
        }
    }
    
    var currentPhrase: String {
        testPhrases[currentTestIndex]
    }
    
    var isLastTest: Bool {
        currentTestIndex == testPhrases.count - 1
    }
    
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Text("Typing Speed Test")
                    .font(.largeTitle)
                
                Spacer()
                
                if !allResults.isEmpty {
                    Button(action: {
                        showingExporter = true
                    }) {
                        Label("Export Data", systemImage: "square.and.arrow.up")
                            .padding(8)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
            }
            .padding()
            
            VStack(alignment: .leading) {
                HStack {
                    Text("Test \(currentTestIndex + 1) of \(testPhrases.count)")
                        .font(.headline)
                    Spacer()
                    if !allResults.isEmpty {
                        Text("Average WPM: \(String(format: "%.1f", averageWPM)) | Error Rate: \(String(format: "%.1f", averageErrorRate))%")
                            .font(.headline)
                    }
                }
                
                Text(currentPhrase)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
            }
            
            if !showingResults {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Type here:")
                        .font(.headline)
                    TextField("Start typing...", text: $userInput)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .focused($isInputFocused)
                        .onAppear { startTest() }
                    
                    Button(action: {
                        submitTest()
                        showingResults = true
                    }) {
                        Text("Submit Test")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(userInput.isEmpty ? Color.gray : Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    .disabled(userInput.isEmpty)
                }
            }
            
            if showingResults {
                VStack(spacing: 15) {
                    Text("Test \(currentTestIndex + 1) Results")
                        .font(.headline)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("WPM: \(String(format: "%.1f", results?.wpm ?? 0))")
                        Text("Error Rate: \(String(format: "%.1f", results?.errorRate ?? 0))%")
                        
                        Divider()
                        
                        Text("Original: \(currentPhrase)")
                            .foregroundColor(.gray)
                        Text("You typed: \(userInput)")
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(10)
                    
                    HStack(spacing: 20) {
                        Button(action: {
                            resetTest()
                            showingResults = false
                        }) {
                            Text("Try Again")
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.gray)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                        
                        if !isLastTest {
                            Button(action: {
                                nextTest()
                                showingResults = false
                            }) {
                                Text("Next Test")
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                            }
                        }
                    }
                }
            }
            
            if !allResults.isEmpty {
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Previous Results:")
                            .font(.headline)
                        ForEach(allResults.indices, id: \.self) { index in
                            HStack {
                                Text("Test \(allResults[index].testIndex + 1):")
                                Text("\(String(format: "%.1f", allResults[index].wpm)) WPM")
                                Text("(Error Rate: \(String(format: "%.1f", allResults[index].errorRate))%)")
                            }
                            .font(.subheadline)
                        }
                    }
                    .padding()
                }
                .frame(maxHeight: 100)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
            }
        }
        .padding()
        .fileExporter(
            isPresented: $showingExporter,
            document: CSVDocument(results: allResults),
            contentType: .commaSeparatedText,
            defaultFilename: "typing_test_results"
        ) { result in
            switch result {
            case .success(let url):
                print("Saved to \(url)")
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    private var averageWPM: Double {
        guard !allResults.isEmpty else { return 0 }
        return allResults.reduce(0.0) { $0 + $1.wpm } / Double(allResults.count)
    }
    
    private var averageErrorRate: Double {
        guard !allResults.isEmpty else { return 0 }
        return allResults.reduce(0.0) { $0 + $1.errorRate } / Double(allResults.count)
    }
    
    private func levenshteinDistance(_ original: String, _ typed: String) -> Int {
        let m = original.count
        let n = typed.count
        
        var dp = Array(repeating: Array(repeating: 0, count: n + 1), count: m + 1)
        
        for i in 0...m {
            dp[i][0] = i
        }
        for j in 0...n {
            dp[0][j] = j
        }
        
        let originalArray = Array(original)
        let typedArray = Array(typed)
        
        for i in 1...m {
            for j in 1...n {
                let cost = originalArray[i - 1] == typedArray[j - 1] ? 0 : 1
                dp[i][j] = min(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        
        return dp[m][n]
    }
    
    private func calculateErrorRate(original: String, typed: String) -> Double {
        let distance = levenshteinDistance(original, typed)
        let maxLength = Double(max(original.count, typed.count))
        return (Double(distance) / maxLength) * 100
    }
    
    private func startTest() {
        startTime = Date()
        isInputFocused = true
    }
    
    private func submitTest() {
        guard let startTime = startTime else { return }
        let timeElapsed = Date().timeIntervalSince(startTime)
        
        let characterCount = userInput.count
        let minutes = timeElapsed / 60
        let wpm = Double(characterCount) / 5.0 / minutes
        let errorRate = calculateErrorRate(original: currentPhrase, typed: userInput)
        
        let newResults = TestResults(
            testIndex: currentTestIndex,
            phrase: currentPhrase,
            wpm: wpm,
            errorRate: errorRate,
            timeElapsed: timeElapsed,
            timestamp: Date()
        )
        
        results = newResults
        allResults.append(newResults)
        isTestActive = false
    }
    
    private func nextTest() {
        if currentTestIndex < testPhrases.count - 1 {
            currentTestIndex += 1
            userInput = ""
            startTime = nil
            isTestActive = true
            results = nil
            isInputFocused = true
            startTest()
        }
    }
    
    private func resetTest() {
        userInput = ""
        startTime = nil
        isTestActive = true
        results = nil
        isInputFocused = true
        startTest()
    }
}

// Document type for CSV export
struct CSVDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.commaSeparatedText] }
    
    var results: [TypingSpeedTest.TestResults]
    
    init(results: [TypingSpeedTest.TestResults]) {
        self.results = results
    }
    
    init(configuration: ReadConfiguration) throws {
        results = []
    }
    
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        let headers = ["Test Number", "Test Phrase", "WPM", "Error Rate", "Time Elapsed (seconds)", "Timestamp"]
        
        var csvString = headers.joined(separator: ",") + "\n"
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .medium
        
        for result in results {
            let row = [
                String(result.testIndex + 1),
                "\"\(result.phrase)\"",
                String(format: "%.1f", result.wpm),
                String(format: "%.1f", result.errorRate),
                String(format: "%.1f", result.timeElapsed),
                "\"\(dateFormatter.string(from: result.timestamp))\""
            ]
            csvString += row.joined(separator: ",") + "\n"
        }
        
        return FileWrapper(regularFileWithContents: Data(csvString.utf8))
    }
}

struct ContentViewA: View {
    var body: some View {
        TypingSpeedTest()
    }
}
