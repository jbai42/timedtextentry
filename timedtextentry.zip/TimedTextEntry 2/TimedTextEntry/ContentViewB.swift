import SwiftUI
import Speech
import AVFoundation

struct SpeechSpeedTest: View {
    let testPhrases = [
        "My watch fell in the water",
        "Prevailing wind from the east",
        "Never too rich and never too thin",
        "Breathing is difficult",
        "I can see the rings on Saturn",
        "Physics and chemistry are hard",
        "My bank account is overdrawn",
        "Elections bring out the best",
        "We are having spaghetti",
        "Time to go shopping"
    ]
    
    @StateObject private var speechRecognizer = SpeechRecognizer()
    @State private var currentTestIndex = 0
    @State private var spokenText = ""
    @State private var startTime: Date?
    @State private var isTestActive = false
    @State private var results: SpeechTestResults?
    @State private var allResults: [SpeechTestResults] = []
    @State private var showingResults = false
    @State private var showingExporter = false
    @State private var isRecording = false
    
    struct SpeechTestResults: Codable {
        let testIndex: Int
        let phrase: String
        let wpm: Double
        let errorRate: Double
        let timeElapsed: TimeInterval
        let timestamp: Date
        
        enum CodingKeys: String, CodingKey {
            case testIndex = "Test Number"
            case phrase = "Test Phrase"
            case wpm = "WPM"
            case errorRate = "Error Rate"
            case timeElapsed = "Time Elapsed (seconds)"
            case timestamp = "Timestamp"
        }
    }
    
    var currentPhrase: String {
        testPhrases[currentTestIndex]
    }
    
    var isLastTest: Bool {
        currentTestIndex == testPhrases.count - 1
    }
    
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Text("Speech Speed Test")
                    .font(.largeTitle)
                
                Spacer()
                
                if !allResults.isEmpty {
                    Button(action: {
                        showingExporter = true
                    }) {
                        Label("Export Data", systemImage: "square.and.arrow.up")
                            .padding(8)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
            }
            .padding()
            
            VStack(alignment: .leading) {
                HStack {
                    Text("Test \(currentTestIndex + 1) of \(testPhrases.count)")
                        .font(.headline)
                    Spacer()
                    if !allResults.isEmpty {
                        Text("Average WPM: \(String(format: "%.1f", averageWPM)) | Error Rate: \(String(format: "%.1f", averageErrorRate))%")
                            .font(.headline)
                    }
                }
                
                Text(currentPhrase)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
            }
            
            if !showingResults {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Recognized Speech:")
                        .font(.headline)
                    Text(spokenText)
                        .padding()
                        .frame(maxWidth: .infinity, minHeight: 50)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                    
                    HStack {
                        Button(action: {
                            if isRecording {
                                stopRecording()
                            } else {
                                startRecording()
                            }
                        }) {
                            HStack {
                                Image(systemName: isRecording ? "stop.circle.fill" : "mic.circle.fill")
                                Text(isRecording ? "Stop Recording" : "Start Recording")
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(isRecording ? Color.red : Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                        }
                        
                        if !spokenText.isEmpty {
                            Button(action: {
                                submitTest()
                                showingResults = true
                            }) {
                                Text("Submit Test")
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                                    .background(Color.green)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                            }
                        }
                    }
                }
            }
            
            if showingResults {
                VStack(spacing: 15) {
                    Text("Test \(currentTestIndex + 1) Results")
                        .font(.headline)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("WPM: \(String(format: "%.1f", results?.wpm ?? 0))")
                        Text("Error Rate: \(String(format: "%.1f", results?.errorRate ?? 0))%")
                        
                        Divider()
                        
                        Text("Original: \(currentPhrase)")
                            .foregroundColor(.gray)
                        Text("You said: \(spokenText)")
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(10)
                    
                    HStack(spacing: 20) {
                        Button(action: {
                            resetTest()
                            showingResults = false
                        }) {
                            Text("Try Again")
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.gray)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                        
                        if !isLastTest {
                            Button(action: {
                                nextTest()
                                showingResults = false
                            }) {
                                Text("Next Test")
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                            }
                        }
                    }
                }
            }
            
            if !allResults.isEmpty {
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Previous Results:")
                            .font(.headline)
                        ForEach(allResults.indices, id: \.self) { index in
                            HStack {
                                Text("Test \(allResults[index].testIndex + 1):")
                                Text("\(String(format: "%.1f", allResults[index].wpm)) WPM")
                                Text("(Error Rate: \(String(format: "%.1f", allResults[index].errorRate))%)")
                            }
                            .font(.subheadline)
                        }
                    }
                    .padding()
                }
                .frame(maxHeight: 100)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
            }
        }
        .padding()
        .fileExporter(
            isPresented: $showingExporter,
            document: SpeechCSVDocument(results: allResults),
            contentType: .commaSeparatedText,
            defaultFilename: "speech_test_results"
        ) { result in
            switch result {
            case .success(let url):
                print("Saved to \(url)")
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    private var averageWPM: Double {
        guard !allResults.isEmpty else { return 0 }
        return allResults.reduce(0.0) { $0 + $1.wpm } / Double(allResults.count)
    }
    
    private var averageErrorRate: Double {
        guard !allResults.isEmpty else { return 0 }
        return allResults.reduce(0.0) { $0 + $1.errorRate } / Double(allResults.count)
    }
    
    private func levenshteinDistance(_ original: String, _ spoken: String) -> Int {
        let m = original.count
        let n = spoken.count
        
        var dp = Array(repeating: Array(repeating: 0, count: n + 1), count: m + 1)
        
        for i in 0...m {
            dp[i][0] = i
        }
        for j in 0...n {
            dp[0][j] = j
        }
        
        let originalArray = Array(original.lowercased())
        let spokenArray = Array(spoken.lowercased())
        
        for i in 1...m {
            for j in 1...n {
                let cost = originalArray[i - 1] == spokenArray[j - 1] ? 0 : 1
                dp[i][j] = min(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        
        return dp[m][n]
    }
    
    private func calculateErrorRate(original: String, spoken: String) -> Double {
        let distance = levenshteinDistance(original, spoken)
        let maxLength = Double(max(original.count, spoken.count))
        return (Double(distance) / maxLength) * 100
    }
    
    private func startRecording() {
        startTime = Date()
        isRecording = true
        spokenText = ""
        speechRecognizer.startRecording { text in
            spokenText = text
        }
    }
    
    private func stopRecording() {
        isRecording = false
        speechRecognizer.stopRecording()
    }
    
    private func submitTest() {
        guard let startTime = startTime else { return }
        let timeElapsed = Date().timeIntervalSince(startTime)
        
        // Calculate WPM based on spoken words
        let wordCount = spokenText.split(separator: " ").count
        let minutes = timeElapsed / 60
        let wpm = Double(wordCount) / minutes
        let errorRate = calculateErrorRate(original: currentPhrase, spoken: spokenText)
        
        let newResults = SpeechTestResults(
            testIndex: currentTestIndex,
            phrase: currentPhrase,
            wpm: wpm,
            errorRate: errorRate,
            timeElapsed: timeElapsed,
            timestamp: Date()
        )
        
        results = newResults
        allResults.append(newResults)
    }
    
    private func nextTest() {
            if currentTestIndex < testPhrases.count - 1 {
                // First stop recording if it's still active
                if isRecording {
                    speechRecognizer.stopRecording()
                    isRecording = false
                }
                
                // Reset the audio session
                do {
                    try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
                } catch {
                    print("Failed to deactivate audio session: \(error)")
                }
                
                // Then proceed with the next test
                currentTestIndex += 1
                spokenText = ""
                startTime = nil
                results = nil
            }
        }
    
    private func resetTest() {
            // First stop recording if it's still active
            if isRecording {
                speechRecognizer.stopRecording()
                isRecording = false
            }
            
            // Reset the audio session
            do {
                try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
            } catch {
                print("Failed to deactivate audio session: \(error)")
            }
            
            spokenText = ""
            startTime = nil
            results = nil
        }
    }


// Speech recognizer class to handle speech recognition
// Modified SpeechRecognizer class
class SpeechRecognizer: ObservableObject {
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    
    func startRecording(onUpdate: @escaping (String) -> Void) {
        // Request authorization
        SFSpeechRecognizer.requestAuthorization { [weak self] status in
            guard let self = self else { return }
            guard status == .authorized else { return }
            
            DispatchQueue.main.async {
                // Set up audio session
                do {
                    let audioSession = AVAudioSession.sharedInstance()
                    try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
                    try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
                } catch {
                    print("Failed to set up audio session: \(error)")
                    return
                }
                
                self.recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
                
                guard let recognitionRequest = self.recognitionRequest else { return }
                
                let inputNode = self.audioEngine.inputNode
                recognitionRequest.shouldReportPartialResults = true
                
                self.recognitionTask = self.speechRecognizer?.recognitionTask(with: recognitionRequest) { result, error in
                    if let result = result {
                        onUpdate(result.bestTranscription.formattedString)
                    }
                }
                
                let recordingFormat = inputNode.outputFormat(forBus: 0)
                inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                    self.recognitionRequest?.append(buffer)
                }
                
                self.audioEngine.prepare()
                
                do {
                    try self.audioEngine.start()
                } catch {
                    print("Failed to start audio engine: \(error)")
                }
            }
        }
    }
    
    func stopRecording() {
            // Remove tap before stopping the audio engine
            if audioEngine.isRunning {
                audioEngine.inputNode.removeTap(onBus: 0)
                audioEngine.stop()
            }
            
            // Cancel recognition task
            recognitionTask?.cancel()
            recognitionTask = nil
            
            // End recognition request
            recognitionRequest?.endAudio()
            recognitionRequest = nil
        }
        
        deinit {
            stopRecording()
        }
    }

// Document type for CSV export
struct SpeechCSVDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.commaSeparatedText] }
    
    var results: [SpeechSpeedTest.SpeechTestResults]
    
    init(results: [SpeechSpeedTest.SpeechTestResults]) {
        self.results = results
    }
    
    init(configuration: ReadConfiguration) throws {
        results = []
    }
    
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        let headers = ["Test Number", "Test Phrase", "WPM", "Error Rate", "Time Elapsed (seconds)", "Timestamp"]
        
        var csvString = headers.joined(separator: ",") + "\n"
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .medium
        
        for result in results {
            let row = [
                String(result.testIndex + 1),
                "\"\(result.phrase)\"",
                String(format: "%.1f", result.wpm),
                String(format: "%.1f", result.errorRate),
                String(format: "%.1f", result.timeElapsed),
                "\"\(dateFormatter.string(from: result.timestamp))\""
            ]
            csvString += row.joined(separator: ",") + "\n"
        }
        
        return FileWrapper(regularFileWithContents: Data(csvString.utf8))
    }
}

struct ContentViewB: View {
    var body: some View {
        SpeechSpeedTest()
    }
}
